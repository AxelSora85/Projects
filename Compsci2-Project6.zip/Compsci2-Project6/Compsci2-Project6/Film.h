#ifndef FILM_CLASS
#define FILM_CLASS
#include <iostream>
#include <string>
#include <fstream>
#include "common.h"

using namespace std;

class Film
{
protected:
	string filmCode;
	string title;
	string year;
	enum FilmRating MPAA;
	enum FilmCategory category;

public:
	Film()
	{
		filmCode = "";
		title = "";
		year = "";
		MPAA = NR;
		category = NoCategory;
		//catergoy set to enumrate for no category
	}

	Film(string f, string t, string y, string MPA, string x)
	{
		//Film* c = this;    //uses the current instance of the customer class
		filmCode = f;
		title =  t;
		year = y;
		MPAA = getFilmRatingEnum(MPA);
		category = getFilmCategoryEnum(x);
		//setFilmRating(MPA);
		
		//setFilmCategory(getFilmCategoryEnum(x));
	}

	bool operator < (const Film& right) {
		bool status = false;

		if (filmCode < right.filmCode) {
			status = true;
		}
		return status;
	}

		bool operator == (const Film& right)
	{
		bool status = false;

		if (filmCode == right.filmCode)
		{
			status = true;
		}
		return status;
	}

	bool operator != (const Film& right)
	{
		bool status = false;

		if (filmCode != right.filmCode)
		{
			status = true;
		}
		return status;
	}

	Film operator = (const char* str) {
		Film f;
		f.filmCode = str;
		return f;
	}

	friend ifstream& operator >> (ifstream& in, Film& f);
	friend ostream& operator << (ostream& strm, Film& f);
	friend ofstream& operator << (ofstream& outfile, Film& f);

	void setFilmCode(const char* str) { filmCode = str; }
	void setFilmTitle(const char* str) { title = str; }
	void setFilmYear(const char* str) { year = str; }
	void setFilmRating(FilmRating r) { MPAA = r; }
	void setFilmCategory(FilmCategory c) { category = c; }
	
	string getFilmCode() { return filmCode; }
	string getFilmTitle() { return title; }
	string getFilmYear() { return year; }
	//string getFilmRating() { return FilmRatingString[MPAA]; }
	string getFilmRating() { string rating = FilmRatingString[MPAA]; }
	string getFilmCategory() { return FilmCategoryString[category]; }
	//string getFilmRating() { return FilmRatingString[MPAA]; }
};


ifstream& operator>> (ifstream& in, Film& f)
{
	string temp;
	in >> f.filmCode;
	in >> f.title;
	in >> f.year;
	in >> temp;
	f.setFilmRating(getFilmRatingEnum(temp));
	in >> temp;
	f.setFilmCategory(getFilmCategoryEnum(temp));
	return in;
}

// overloading << 
//overloading the stream functions
ofstream& operator << (ofstream& outfile, Film& f) {
	outfile << f.filmCode << " ";
	outfile << f.title << " ";
	outfile << f.year << " ";
	outfile << FilmRatingString[f.MPAA] << " ";
	outfile << FilmCategoryString[f.category] << endl;
	return outfile;
}
ostream& operator << (ostream& strm, Film& f)
{
	strm << f.filmCode << " ";
	strm << f.title << " ";
	strm << f.year << " ";
	strm << FilmRatingString[f.MPAA] << " ";
	strm << FilmCategoryString[f.category] << endl;
	return strm;
}



#endif

