
#include <fstream>
#include <iomanip>
#include "personc.h"
#include "film.h"
#include "rental.h"
#include "company.h"
#include "Videostore.h"

using namespace std;

int main()
{

	RetCode result;

	ofstream outputFile("project6.out", ios::out);

	VideoStore videostore;

	// output all data to video_store.out
	outputFile << videostore;

	// close video_store.out
	outputFile.close();

	// output all the data to the screen (optional)
	//cout << videostore;

	
	Customer customer ("C0036", "Doe", "John", "1000_Doe_Drive", "Dearborn", "MI", "48045","458-458-548","05/16/19");
	Employee employee("E00111", "Mark", "Matthew", "1000_Doe_Drive", "Dearborn", "MI", "555-666-771", "48045", 15.3f);
	Film film("F1023", "The_Matrix", "1999", "PG13", "Science_Fiction");
	Rental rental ("C02034", "F9923", "05/16/19", "18:27", "01/04/19");

	Customer customer2("C0001", "Hannah", "Banana", "1000_Doe_Drive", "Dearborn", "MI", "48045", "458-458-548", "05/16/19");
	Employee employee2 ("E0001", "Mark", "Jack", "1000_Doe_Drive", "Dearborn", "MI", "555-666-771", "48045", 15.3f);
	Film film2 ("F1023", "The_Matrix", "1999", "PG13", "Science_Fiction");
	Rental rental2 ("C02034", "F9923", "05/16/19", "18:27", "01/04/19");
					
	videostore.Add(customer);
	videostore.Add(employee);
	videostore.Add(film);
	videostore.Add(rental);


	////cout << rental;
	videostore.Add(customer2);
	videostore.Add(employee2);
	videostore.Add(film2);
	videostore.Add(rental2);


	

	cout << "\n Deleting Customer " << " result = ";
	result = videostore.RemoveCustomer("C0026");
	cout << result;
	
	cout << "\n Deleting Employee " << " result = ";
	result = videostore.removeEmployee("E0010");
	cout << result;

	cout << "\n Deleting Film " << " result = ";
	result = videostore.Removefilm("C0026");
	cout << result;


	cout << "\n Deleting Customer " << " result = ";
	result = videostore.Removerental("C0026");
	cout << result;


	videostore.lookupCustomer("C011");
	videostore.lookupEmployee("E0011");
	videostore.lookupfilm("F0011");
	videostore.lookupRental("C0011");

	system("pause");
	
	outputFile << videostore;
	
	outputFile.close();
	
	
	cout << "\n The output has been written to project6.out" << endl;

	system("pause");

	return 0;
}