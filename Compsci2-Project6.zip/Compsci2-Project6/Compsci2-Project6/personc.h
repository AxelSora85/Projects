


#ifndef PERSONC_H
#define PERSONC_H

#include <fstream>
#include <string>
#include "common.h"
using namespace std;

class Person
{
protected:
	string lastName;
	string firstName;
	string address;
	string city;
	StateAbbr state;
	string zipCode;
	string telephone;

public:
	Person()
	{
		firstName = "";
		lastName = "";
		address = "";
		city = "";
		state = NOSTATE;
		zipCode = "";
		telephone = "";
	}
	//person takes in 7 paramters!!
	Person(string lname, string fname, string addrs, string citystr, string statestr, string zip, string phone)
	{

		lastName = lname;
		firstName = fname;
		address = addrs;
		city = citystr;
		//state = statestr;
		zipCode = zip;
		telephone = phone;

	}


	friend ifstream& operator >> (ifstream& infile, Person* p);
	friend ofstream& operator << (ofstream& outfile, Person* p);
	friend ostream& operator << (ostream& strm, Person* p);

	void setLastName(const string str) { lastName = str; }
	void setFirstName(const string str) { firstName = str; }
	void setAddress(const string str) { address = str; }
	void setCity(const string str) { city = str; }
	void setState(const string str) { state = getStateEnum(str); }
	void setZipCode(const string str) { zipCode = str; }
	void setTelephone(const string str) { telephone = str; }

	string getLastName() { return lastName; }
	string getFirstName() { return firstName; }
	string getAddress() { return address; }
	string getCity() { return city; }
	const string getState() { return getStateString(state); }
	string getZipCode() { return zipCode; }
	string getTelephone() { return telephone; }
};


ifstream& operator >> (ifstream& infile, Person* p)
{
	string stateString;

	infile >> p->lastName;
	infile >> p->firstName;
	infile >> p->address;
	infile >> p->city;
	infile >> stateString;
	p->state = getStateEnum(stateString);
	infile >> p->zipCode;
	infile >> p->telephone;

	return infile;
}



ostream& operator << (ostream& strm, Person* p)
{
	strm << p->lastName << " ";
	strm << p->firstName << " ";
	strm << p->address << " ";
	strm << p->city << " ";

	strm << getStateString(p->state) << " ";
	strm << p->zipCode << " ";
	strm << p->telephone << " ";
	return strm;
}

ofstream& operator << (ofstream& outfile, Person* p)
{
	outfile << p->lastName << " ";
	outfile << p->firstName << " ";
	outfile << p->address << " ";
	outfile << p->city << " ";
	outfile << p->telephone << " ";
	outfile << getStateString(p->state) << " ";
	outfile << p->zipCode << " ";

	return outfile;
}

#endif

