#ifndef  COMPANY_CLASS
#define COMPANY_CLASS


#include <string>
#include <fstream>
#include "common.h"
#include "Employee.h"
#include "customer.h"
#include "template_linkedlist.h"

using namespace std;

class Company : public Employee {
protected:
	string companyName;
	string address;
	string city;
	StateAbbr state;
	string zipCode;
	string telephone;

	Employee e;

	LinkedList <Employee> employeeList;

public: //ifstream will be used here to print to the out file
	Company() {
		ifstream employeeInputFile("employees.txt");
		string stateString;

		employeeInputFile >> companyName;
		employeeInputFile >> address;
		employeeInputFile >> city;
		employeeInputFile >> stateString;
		state = getStateEnum(stateString);
		employeeInputFile >> zipCode;
		employeeInputFile >> telephone;

		while (!employeeInputFile.eof()) {
			employeeInputFile >> e;
			employeeList.appendNode(e);
		}
		employeeInputFile.close();

	}

	friend ofstream& operator << (ofstream& outfile, Company* c);

	void setCompanyName(string str) { companyName = str; }
	void setCompanyAddress(string str) { address = str; }
	void setCompanyCity(string str) { city = str; }
	void setCompanyState(StateAbbr str) { state = str; }
	void setCompanyZipcode(string str) { zipCode = str; }
	void setCompanyTelephone(string str) { telephone = str; }

	void Add(Employee& c){
		Employee employee = c;
		employeeList.insertNode(employee);
	}

	RetCode removeEmployee(string id)
	{
		RetCode result;

		Employee employee;
		employee.setEmployeeNumber(id);
		result = employeeList.searchNode(employee);

		if (result==Success)
		{
			employeeList.deleteNode(employee);

		}
		return result;



	}

	void lookupEmployee(string id)
	{
		RetCode result;
		Employee employee;

		employee.setEmployeeNumber(id);
		result = employeeList.searchNode(employee);

		if (result==Success)
		{
			employee = employeeList.getNode(employee);
			cout << "\n Employee Found: " << endl;
			cout << employee << endl;


		}
		else
		{
			cout << "\n Employee" << id << "Not Found" << endl;

		}




	}

};

ofstream& operator << (ofstream& outfile, Company* c) {
	Employee* e = c;  // uses the currwent instance of employee
	//this function writes to the outputfile and writes the company name before the break betwween the employee data is written
	outfile << "Company" << endl;
	outfile << "-------" << endl;
	outfile << c->companyName << " ";
	outfile << c->address << " ";
	outfile << c->city << " ";
	outfile << getStateString(c->state) << " ";
	outfile << c->zipCode << " ";
	outfile << c->telephone << endl;

	outfile << "Employee:" << endl;
	outfile << "--------" << endl;

	c->employeeList.printListToFile(outfile);
	c->employeeList.displayList();


	return outfile;
}



#endif 

