#ifndef STORE_H
#define STORE_H
#include <string>
#include <fstream>
#include "template_linkedlist.h"
#include "company.h" 
#include "customer.h"

class Store : public Company
{
protected:

	Customer customer;
	LinkedList <Customer> customerList;

public:


	Store() : Company()
	{
		ifstream customerInputFile("customers.txt");

		while (!customerInputFile.eof())
		{
			customerInputFile >> customer;
			customerList.appendNode(customer);
		}
		customerInputFile.close();
	}


	friend ofstream& operator << (ofstream& out, Store* s);
	

	Customer& getCustomer(char* customerId) { ; }

	void Add(Customer& c){
		Customer customer = c;
		customerList.insertNode(customer);
	} 
	
	//bool operator < (const Customer& right) {
	//	bool status = false;

	//	if (customerNumber < right.customerNumber) {
	//		status = true;
	//	}
	//	return status;
	//}


	RetCode AddCustomer(Customer& c) { customerList.appendNode(customer); }
	//RetCode RemoveCustomer(const char* id) { ; }
	Customer* LookupId(const char* id) { ; }

	void lookupCustomer(string id)
	{
		RetCode result;
		Customer customer;

		customer.setCustomerNumber(id);
		result = customerList.searchNode(customer);

		if (result==Success)
		{
			customer = customerList.getNode(customer);
			cout << "\n Cutsomer found " << endl;
			cout << customer << endl;


		}
		return;
	}

	//bool operator < (const Customer& right) {
	//	bool status = false;

	//	if (getCustomer < right.) {
	//		status = true;
	//	}
	//	return status;
	//}



	RetCode RemoveCustomer(string id)
	{
		RetCode result;
		Customer customer;
		customer.setCustomerNumber(id);
		result = customerList.searchNode(customer);
		if (result == Success)
		{
			customerList.deleteNode(customer);
		}
		return result;

	}
	
};

//void Add(Customer& c)
//{
//		Customer customer = c;
//		customerList.in
//}

//this function writes to the outputfile and writes the title of the next upcoming data or class being used in the file.
ofstream& operator << (ofstream& outfile, Store* s)
{
	Company* c = s;


	/* output all the company attributes which includes the employees */
	outfile << c;

	outfile << "STORE: " << endl;
	outfile << "---------" << endl;

	outfile << "Customers:" << endl;
	outfile << "----------" << endl;

	/* output all of the customers */
	s->customerList.printListToFile(outfile);
	s->customerList.displayList();

	return outfile;
}


#endif
