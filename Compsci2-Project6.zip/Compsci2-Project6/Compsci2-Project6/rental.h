#ifndef RENTALS
#define RENTALS
#include <iostream>
#include <vector>
#include "common.h"


//functions for date will run through to find the right date 
using namespace std;

class Rental {
protected:
	string customerNumber;
	string filmCode;
	Date dateRented;
	string timeRented;
	Date dateDue;
public:
	
	Rental() {

	}

	Rental(string customerNumber, string filmCode, Date dateRented, string timeRented, Date dateDue) {
		Rental* e = this;
		
	}
	
	Rental(string customer, string film, string date1, string time, string date) {
		customerNumber = customer;
		filmCode = film;

		string temp = date1;
		setDateRented(temp);
		dateRented = *getdateRented();
		timeRented = time;
		string temp2 = date;
		setDateDue(temp2);
		dateRented = *getdateDue();
		
	}

	

	bool operator < (const Rental& right) {
		bool status = false;

		if (customerNumber < right.customerNumber) {
			status = true;
		}
		return status;
	}


	bool operator == (const Rental& right)
	{
		bool status = false;

		if (customerNumber == right.customerNumber)
		{
			status = true;
		}
		return status;
	}

	bool operator != (const Rental& right)
	{
		bool status = false;

		if (customerNumber != right.customerNumber)
		{
			status = true;
		}
		return status;
	}


	Rental operator = (const char* str) {
		Rental r;
		r.customerNumber = str;
		return r;
	}

	void setcustomerNumber(string str) { customerNumber = str; }
	void setfilmCode(string str) { filmCode = str; }
	void setDateRented(string str) {

		size_t position1;
		size_t position2;
		string date;

		date = str;
		date.shrink_to_fit();
		position1 = date.find("/", 0);
		dateRented.month = date;
		position2 = date.find("/", position1 + 1);
		dateRented.day = date.substr(position1 + 1, position2 - position1 - 1);
		dateRented.year = date.substr(position2 + 1, date.length() - position2);
	}
	void setTime(const string str) { timeRented = str; }
	void setDateDue(const string str) {
		string date;
		int position1;
		int position2;

		date = str;
		date.shrink_to_fit();
		position1 = date.find("/", 0);
		dateDue.month = date;
		position2 = date.find("/", position1 + 1);
		dateDue.day = date.substr(position1 + 1, position2 - position1 - 1);
		dateDue.year = date.substr(position2 + 1, date.length() - position2);
	}


	friend ifstream& operator >> (ifstream& infile, Rental& r);
	friend ofstream& operator << (ofstream& outfile, Rental& r);
	friend ostream& operator << (ostream& str, Rental& r);

	string getcustomerNumber() { return customerNumber; }
	string getfilmCode() { return filmCode; }
	Date* getdateRented() { return &dateRented; }
	string gettimeRented() { return timeRented; }
	Date* getdateDue() { return &dateDue; }
	Date* getDateRented() { return &dateRented; }
	Date* getDateDue() { return &dateDue; }



	//dates are pointers
	//all dates are pointers for the other files

};


ofstream& operator << (ofstream& outfile, Rental& r) {
	outfile << r.customerNumber << " ";
	outfile << r.filmCode << " ";
	outfile << r.dateRented.month << "/";
	outfile << r.dateRented.day << "/";
	outfile << r.dateRented.year << "/";
	outfile << r.timeRented << "/";
	outfile << r.dateDue.month << "/";
	outfile << r.dateDue.day << "/";
	outfile << r.dateDue.year << endl;
	return outfile;
}
ifstream& operator >> (ifstream& infile, Rental& r) {
	string date;
	vector<string> tokens;


	infile >> r.customerNumber;
	infile >> r.filmCode;
	infile >> date;

	r.setDateRented(date);

	infile >> r.timeRented;
	infile >> date;

	r.setDateDue(date);

	return infile;
}



ostream& operator << (ostream& str, Rental& r) {
	str << r.customerNumber << " ";
	str << r.filmCode << " ";
	str << r.dateRented.month << "/";
	str << r.dateRented.day << "/";
	str << r.dateRented.year << "/";
	str << r.timeRented << "/";
	str << r.dateDue.month << "/";
	str << r.dateDue.day << "/";
	str << r.dateDue.year << endl;
	return str;
}


#endif

