
#ifndef VIDEOSTORE_H
#define VIDEOSTORE_H

#include"template_linkedlist.h"
#include "Store.h"
//#include"Film.h"
//#include"rental.h"


class VideoStore : public Store
{

private:

	Film film;
	Rental rental;
	LinkedList <Film> filmList;
	LinkedList <Rental> rentalList;

public:

	VideoStore()
		: Store()
	{
		ifstream filmInputFile("films.txt");
		ifstream rentalInputfile("rentals.txt");

		/* open output file*/
		ofstream outputFile("project6.out");

		while (!filmInputFile.eof())
		{
			filmInputFile >> film;
			filmList.appendNode(film);
		}
		filmInputFile.close();


		while (!rentalInputfile.eof())
		{
			rentalInputfile >> rental;
			rentalList.appendNode(rental);
		}

		rentalInputfile.close();
	}

	//bool operator < (const Employee& right)
	//{
	//	bool status = false;

	//	if (employeeNumber < right.employeeNumber)
	//	{
	//		status = true;
	//	}
	//	return status;
	//}



	//bool operator != (const Employee& right)
	//{
	//	bool status = false;

	//	if (employeeNumber != right.employeeNumber)
	//	{
	//		status = true;
	//	}
	//	return status;
	//}

	void Add(Rental& r)
	{
		Rental rental = r;
		rentalList.insertNode(rental);
	}

	virtual void Add(Customer& c)
	{
		Customer customer = c;
		Store::Add(c);
	}

	void Add(Employee& e)
	{
		Employee employee = e;
		Company::Add(e);
	}

	void Add(Film & f)
	{
		Film film = f;
		filmList.insertNode(film);
	}

	RetCode Removefilm(string fcode)
	{
		RetCode result;
		//string str = "std::string to const char*";
 
		char const *c = fcode.data();
		
 
		Film film;
		film.setFilmCode(c);
		result = filmList.searchNode(film);
		if (result== Success)
		{
			filmList.deleteNode(film);


		}
		return result;
	}

	RetCode Removerental(string rld)
	{
		RetCode result = Success;

		Rental rental;
		rental.setcustomerNumber(rld);

		while (result== Success)
		{
			result = rentalList.searchNode(rental);
			if (result==Success)
			{
				rentalList.deleteNode(rental);
			}
			return result;

		}
	}

	void lookupfilm(string id)
	{
		RetCode result;
		Film film;
		char const *c = id.data();
		film.setFilmCode(c);
		result = filmList.searchNode(film);

		if (result == Success)
		{
			film = filmList.getNode(film);
			cout << "\n Film Found: " << endl;
			cout << film << endl;
		}
		else
		{
			cout << " \nFilm " << id << "Not Found" << endl;

		}
		return;

	}

	void lookupRental(string id)
	{
		RetCode result;
		Rental rental;

		rental.setcustomerNumber(id);
		result = rentalList.searchNode(rental);

		if (result == Success)
		{
			rental = rentalList.getNode(rental);
			cout << "\n Rental Found  " << endl;
			cout << film << endl;
		}
		else
		{
			cout << "\n Rental: " << id << " Not Found " << endl;

		}
		return;

	}
	 
	 
	//set address of v equal to the pointer somehow?
	// this function will write headers between the two sections in the outputfile 
	friend ofstream& operator<< (ofstream& outfile, VideoStore& v)
	{
		Store* s = &v; // current instance of the class with using the this operator?

		outfile << "The Video Store:" << endl;
		outfile << "----------------" << endl;

		// Print out the store 
		outfile << s;

		//outfile << c; // Prints Comp name/Employees
		//outfile << s; // Prints Customers
		outfile << "The Films:" << endl;
		outfile << "----------" << endl;

		v.filmList.printListToFile(outfile);
		v.filmList.displayList();

		outfile << "The Film Rentals:" << endl;
		outfile << "-----------------" << endl;
		v.rentalList.printListToFile(outfile);
		v.rentalList.displayList();


		return outfile;
	}

	


};

#endif
