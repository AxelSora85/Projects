#ifndef CUSTOMER
#define CUSTOMER
#include <iostream>
//#include something else

#include "personc.h"
//set the class as a  parent to the person class 
using namespace std;

class Customer : public Person {
protected:
	string customerNumber;

public:
	void setCustomerNumber(const string str) { customerNumber = str; }
	string getCustomerNumber() {
		return customerNumber;
	}
	Customer() {
		customerNumber = "";
	}
	//customer will take in 9 parameters and person will take in 7 parameters here
	Customer(string id, string lname, string fname, string address, string city, string state, string phone, string zip, string reqistration_date) :
		Person(lname, fname, address, city, zip, phone, state)
	{
		Customer* c = this;    //uses the current instance of the customer class
		customerNumber = id;
	}

	bool operator < (const Customer& right) {
		bool status = false;

		if (customerNumber < right.customerNumber) {
			status = true;
		}
		return status;
	}

	bool operator == (const Customer& right) {
		bool status = false;
		if (customerNumber == right.customerNumber)
			status = true;
		return status;
	}

	bool operator != (const Customer& right) {
		bool status = false;
		if (customerNumber != right.customerNumber) {
			status = true;
		}
		return status;
	}

	Customer operator = (string str) {
		Customer customer;
		customer.customerNumber = str;
		return customer;
	}

	~Customer() {

	}

	friend ifstream& operator >> (ifstream& infile, Customer& c);
	friend ofstream& operator << (ofstream& outfile, Customer* c);
	friend ostream& operator << (ostream& strm, Customer& c);


};

ifstream& operator >> (ifstream& infile, Customer& c) {
	Person* p = &c;// used for the current instance of the person class with the pointer 

	string date;

	infile >> c.customerNumber;
	infile >> p;
	infile >> date;
	/*while (!infile.eof()) {
		infile >> c.customerNumber;
		infile >> p;
		infile >> date;

		int position1;
		int position2;

		date.shrink_to_fit();
		position1 = date.find("/", 0);
		dateRented.month = date;
		position2 = date.find("/", position1 + 1);
		dateRented.day = date.substr(position1 + 1, position2 - position1 - 1);
		dateRented.year = date.substr(position2 + 1, date.length() - position2);
	}*/
	return infile;
}

ofstream& operator << (ofstream& outfile, Customer* c) {
	Person* p = c;

	outfile << c->customerNumber << " ";
	outfile << p;

	return outfile;
}

ostream& operator << (ostream& strm, Customer& c) {
	Person* p = &c;

	strm << c.customerNumber << " ";
	strm << p;

	return strm;
}


#endif
