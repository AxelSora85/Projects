//Nathan Ford
//Assignment 4
//Java MCS3603
//"I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own."

//Mangos=tea ,watermellon = milk, banna=bread
//fruit will be the base variable for products
// fruit names did not work out price wise. Changed to orginal items for higher prices

public class Invoice extends displayInvoice {
    
    public Invoice() throws Exception {
        super();
        //TODO Auto-generated constructor stub
    }

    public void saveInvoice(String first, String last, String id, double apple, 
            double orange, double watermelon, double pear, double peach, double total, double finalCost) throws java.io.IOException{
        
        java.io.File file = new java.io.File("Invoice.txt");//create text file named n=invoice
        
        if(file.exists()){
            System.out.println("Invoice already exists");//will display this message if file already exists
    }
    
        try (java.io.PrintWriter out = new java.io.PrintWriter(file) //used to write to file invoice
        ) {
            DiscountCheck check = new DiscountCheck();//utilizing discount check method to check for 10 or more items
            // apple = milk, orange = Tea = 4.28, watermelon = Bread = 6.72
            out.println("************************************");//format for external file creation
            out.println("Thank you for shopping at the Quickeie - Mart");
            out.println("************************************");
            out.println("Customer name: "+ first + " "+ last);
            out.println("Customer ID: "+ id);
            out.println("************************************");
            out.println("Your Order: ");
            out.printf("%.0f" + " Milk ---------- $"+ "%1.2f\n", apple, check.checkDiscount(apple , 10.26));
            out.printf("%.0f" + " Tea  ---------- $"+ "%1.2f\n", orange, check.checkDiscount(orange , 4.28));
            out.printf("%.0f" + " Bread ------ $"+ "%1.2f\n", watermelon, check.checkDiscount(watermelon , 6.72));
            out.printf("%.0f" + " Pear's ------------ $"+ "%1.2f\n", pear, check.checkDiscount(pear , 1.50));
            out.printf("%.0f" + " Peach's ----------- $"+ "%1.2f\n", peach, check.checkDiscount(peach , 1.75));
            out.println("************************************");
            out.printf("Total Before Tax: $"+"%1.2f\n" , total);
            out.printf("Total After Tax: $"+"%1.2f\n" , finalCost);
            out.println("************************************");
            out.println("Thank you for shopping at the Quicke - Mart");
            out.println("************************************"); 
        } //utilizing discount check method to check for 10 or more items
        catch(Exception ex){
            System.out.println("Cannot Make Invoice");
        }
    }  
}