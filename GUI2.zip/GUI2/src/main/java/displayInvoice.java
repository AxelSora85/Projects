//Nathan Ford
//Assignment 4
//Java MCS3603
//"I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own."

//Mangos=tea ,watermellon = milk, banna=bread
//fruit will be the base variable for products
// fruit names did not work out price wise. Changed to orginal items for higher prices

public class displayInvoice extends textStuffs{//this method is used to populate a new GUI menu for the invoice
    public displayInvoice()throws Exception{
            
    
    }   
}

