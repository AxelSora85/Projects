//Nathan Ford
//Assignment 4
//Java MCS3603
//"I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own."

//Mangos=tea ,watermellon = milk, banna=bread
//fruit will be the base variable for products
// fruit names did not work out price wise. Changed to orignal items for higher prices

import javax.swing.JFrame;//imports for this file

public class DiscountCheck extends JFrame {//this file extends JFrame to enable functionality for our GUI
    
    public double checkDiscount(double fruit, double price){//Checks if more than 10 of one item has been bought
        if(fruit >= 10){
            price = fruit * price * 0.90; 
        }
        else{
            price = fruit * price; 
        }
            return price;
    }
    
}
