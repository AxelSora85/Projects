#ifndef PERSONC_H
#define PERSONC_H

#pragma once







#include <string>

using namespace std;

class Person
{
private:

	string employeeNumber;
	string lastName;
	string firstName;
	string address;
	string city;
	string state;
	string zipCode;
	string telephone;
	string date;


	static unsigned int employeeCount;


public:
	//float  wage;

	void setEmployeeNumber(const string str)
	{
		employeeNumber = str;
	}
	string getEmployeeNumber()
	{
		return employeeNumber;

	}


	Person()
	{
		employeeNumber = "";
		firstName = "";
		lastName = "";
		address = "";
		city = "";
		zipCode = "";
		telephone = "";
		date = "";
		employeeCount = 0U;


		//wage = 0.0f;
	}

	friend ifstream& operator >> (ifstream& infile, Person e[]);
	friend ofstream& operator << (ofstream& outfile, Person e[]);
	friend ostream& operator << (ostream& strm, Person e[]);

	void setLastName(const string str) { lastName = str; }
	void setFirstName(const string str) { firstName = str; }
	void setAddress(const string str) { address = str; }
	void setCity(const string str) { city = str; }
	void setState(const string str) { state = str; }
	void setZipCode(const string str) { zipCode = str; }
	void setTelephone(const string str) { telephone = str; }
	void setDate(const string str) { date = str; }
	void AddEmployee() { employeeCount++; }

	string getLastName() { return lastName; }
	string getFirstName() { return firstName; }
	string getAddress() { return address; }
	string getCity() { return city; }
	string getState() { return state; }
	string getZipCode() { return zipCode; }
	string getTelephone() { return telephone; }
	string getDate() { return date; }

	unsigned int getEmployeeCount() { return employeeCount; }
};




#endif

