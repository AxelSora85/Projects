
#ifndef CUSTOMER_H
#define CUSTOMER_H
#include"personc.h"





#include <string>

using namespace std;

class Customer: public Person
{
private:

	string employeeNumber;
	string lastName;
	string firstName;
	string address;
	string city;
	string state;
	string zipCode;
	string telephone;
	string date;


	static unsigned int employeeCount;


public:
	//float  wage;

	void setEmployeeNumber(const string str)
	{
		employeeNumber = str;
	}
	string getEmployeeNumber()
	{
		return employeeNumber;

	}


	Customer()
	{
		employeeNumber = "";
		firstName = "";
		lastName = "";
		address = "";
		city = "";
		zipCode = "";
		telephone = "";
		date = "";
		employeeCount = 0U;


		//wage = 0.0f;
	}

	friend ifstream& operator >> (ifstream& infile, Customer e[]);
	friend ofstream& operator << (ofstream& outfile, Customer e[]);
	friend ostream& operator << (ostream& strm, Customer e[]);

	void setLastName(const string str) { lastName = str; }
	void setFirstName(const string str) { firstName = str; }
	void setAddress(const string str) { address = str; }
	void setCity(const string str) { city = str; }
	void setState(const string str) { state = str; }
	void setZipCode(const string str) { zipCode = str; }
	void setTelephone(const string str) { telephone = str; }
	void setDate(const string str) { date = str; }
	void AddEmployee() { employeeCount++; }

	string getLastName() { return lastName; }
	string getFirstName() { return firstName; }
	string getAddress() { return address; }
	string getCity() { return city; }
	string getState() { return state; }
	string getZipCode() { return zipCode; }
	string getTelephone() { return telephone; }
	string getDate() { return date; }

	unsigned int getEmployeeCount() { return employeeCount; }
};




#endif