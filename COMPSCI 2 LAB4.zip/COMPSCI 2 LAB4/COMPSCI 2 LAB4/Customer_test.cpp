// Nathan Ford
//Project 2
//I have neither given nor received unauthorized aid in completing this work, nor have I presented someone else's work as my own


#include <iostream>
#include <fstream>
#include<iomanip>

#include "Customer.h"
#include "Customer_Test.h"
#include"personc.h"

#define d customerz 


using namespace std;

int main()
{

	ofstream outputFile("customers.out", ios::out);
	ifstream  inputFile("customers.txt", ios::in);

	Person Customerz[100];

	inputFile >> Customerz;

	cout << "\n The output has been written to customer.out" << endl;
	int i = 0;
	while (i < Customerz[i].getEmployeeCount())
	{
		//cout << Customerz[i].getEmployeeNumber() << SPACE << Customerz[i].getLastName() << SPACE << Customerz[i].getFirstName() << SPACE << Customerz[i].getAddress() << SPACE << Customerz[i].getCity()
		//<< SPACE << Customerz[i].getState() << SPACE << Customerz[i].getZipCode() << SPACE << Customerz[i].getTelephone() << SPACE  << endl;
		//++;
		cout << left;
		cout << setw(10) << Customerz[i].getEmployeeNumber() << SPACE;
		cout << setw(10) << Customerz[i].getLastName() << SPACE;
		cout << setw(10) << Customerz[i].getFirstName() << SPACE;
		cout << setw(20) << Customerz[i].getAddress() << SPACE;
		cout << setw(16) << Customerz[i].getCity() << SPACE;
		cout << setw(10) << Customerz[i].getState() << SPACE;
		cout << setw(10) << Customerz[i].getZipCode() << SPACE;
		cout << setw(10) << Customerz[i].getTelephone() << SPACE;
		cout << setw(10) << Customerz[i].getDate() << SPACE << endl;
		i++;
	}

	//cout << Customerz;

	outputFile << Customerz;

	outputFile.close();


	system("pause");

	return 0;
}