#include <fstream>
#include <string>
#include<iostream>
#include<iostream>
#include<iomanip>

#include "Customer.h"
#include "Customer_Test.h"

using namespace std;

ifstream& operator >> (ifstream& infile, Person e[])
{

	//string strWage;      // read hourly wage as a string

	unsigned int i = 0u;

	while (!infile.eof())
	{
		infile >> e[i].employeeNumber;
		infile >> e[i].lastName;
		infile >> e[i].firstName;
		infile >> e[i].address;
		infile >> e[i].city;
		infile >> e[i].state;
		infile >> e[i].zipCode;
		infile >> e[i].telephone;
		infile >> e[i].date;

		//infile >> strWage;
		//e[i].wage = stof(strWage);
		e[i].AddEmployee();
		i++;
		if (i > 100)
		{
			break;
		}
	}

	return infile;
}

ofstream& operator << (ofstream& outfile, Person  e[])
{
	for (unsigned int i = 0; i < e->employeeCount; i++)
	{
		outfile << left;
		outfile << setw(10) << e[i].employeeNumber << SPACE;
		outfile << setw(10) << e[i].lastName << SPACE;
		outfile << setw(10) << e[i].firstName << SPACE;
		outfile << setw(20) << e[i].address << SPACE;
		outfile << setw(16) << e[i].city << SPACE;
		outfile << setw(10) << e[i].state << SPACE;
		outfile << setw(10) << e[i].zipCode << SPACE;
		outfile << setw(10) << e[i].telephone << SPACE;
		outfile << setw(10) << e[i].date << SPACE << endl;


		//outfile << to_string(e[i].wage) << endl;
	}

	return outfile;
}

//ostream& operator << (ostream& strm, Customer  e[])
//{
//	for (unsigned int i = 0; i < e->employeeCount; i++)
//	{
//		strm << e[i].employeeNumber << SPACE ;
//		strm << e[i].lastName << SPACE ;
//		strm << e[i].firstName << SPACE;
//		strm << e[i].address << SPACE ;
//		strm << e[i].city << SPACE ;
//		strm << e[i].state << SPACE ;
//		strm << e[i].zipCode << SPACE ;
//		strm << e[i].telephone << SPACE ;
//		strm << e[i].date << SPACE << endl;

//		//strm << to_string(e[i].wage) << endl;
//	}

//	return strm;
//}

unsigned int Person::employeeCount = 0;