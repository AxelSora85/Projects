#include "calculator.h"
#include <float.h>
#include "math.h"

double calculateExponential(double x)
{

	

	

		//if(x == 0)
		//{
		//	result = 1; 
		//	return result;

		//}
		//else if(x == 1)
		//{
		//	result = exp(1);
		//	return result; 
		//}
		//else
		//{
		double placeHolder = 1;

		for (int y = 1; y <= 100; y++)
		{
			if (y == 1)
				placeHolder = placeHolder + x; 
			else
				placeHolder = placeHolder + (pow(x, y) / factorial_function(y));

		}
		return placeHolder;
		//}


	

	//double result = 0.0f;

	//return result;
}